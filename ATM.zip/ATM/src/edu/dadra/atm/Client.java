package edu.dadra.atm;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.Scanner;

public class Client {
	
	private final static String HOST = "127.0.0.1";
	private final static int PORT = 7777;
	
	public static void main(String[] args) throws UnknownHostException, IOException {
		
		String amount = "0";
		
		Socket s = new Socket(HOST, PORT);
		InputStream is = s.getInputStream();
		OutputStream os = s.getOutputStream();
		Scanner sc = new Scanner(System.in);
		
		//Access to account
		System.out.println("Nhap so the: ");
		String sothe = sc.nextLine();
		System.out.println("Nhap ma PIN: ");
		String maPIN = sc.nextLine();
		String request = "CARDNUMBER"+sothe+"ENDCARDNUMBER PIN"+maPIN+"ENDPIN"+" REQUESTLOGINENDREQUEST";
		os.write(request.getBytes());
		
		int check = 0;
		byte[] dataByte = new byte[100];
		check = is.read(dataByte);
		String loginResponse = new String(dataByte).trim();
		if(loginResponse.equals("valid")) {
			System.out.println("Dang nhap thanh cong");
		} else {
			System.out.println("Thong tin khong chinh xac");
			return;
		}
		
		while(true) {
			System.out.println("\t1. Kiem tra so du");
			System.out.println("\t2. Rut tien");
			String input = sc.nextLine();
			if(input.equals("1")) {
				request = "CARDNUMBER"+sothe+"ENDCARDNUMBER REQUESTCHECKENDREQUEST";
				break;
			} else if(input.equals("2")) {
				System.out.println("Nhap so tien: ");
				amount = sc.nextLine();
				request = "CARDNUMBER"+sothe+"ENDCARDNUMBER REQUESTWITHDRAWENDREQUEST AMOUNT"+amount+"ENDAMOUNT";
				break;
			} else {
				System.out.println("Yeu cau khong hop le. Vui long nhap lai!");
			}
		}
					
		os.write(request.getBytes());
		
		check = 0;
		byte[] b = new byte[1000];
		check = is.read(b);
		String withdrawResponse = new String(b).trim();
		System.out.println(withdrawResponse);
		
	}
	
}
