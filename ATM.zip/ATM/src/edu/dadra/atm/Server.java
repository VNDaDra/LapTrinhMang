package edu.dadra.atm;

import java.io.IOException;
import java.io.InputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

public class Server {
	
	public final static int PORT = 7777;
	
	public static void main(String[] args) throws InterruptedException, IOException {
		
		ServerSocket ss = null;
		Socket s = null;
		
		ss = new ServerSocket(PORT);
		System.out.println("Starting server on port " + PORT);
		
		while(true) {
			s = ss.accept();
			System.out.println("Connected to "+s.getInetAddress());
			RequestProcessor requestProcessor = new RequestProcessor(s);
			requestProcessor.start();
		}
	}
}