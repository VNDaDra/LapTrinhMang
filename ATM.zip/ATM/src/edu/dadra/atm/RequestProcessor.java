package edu.dadra.atm;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormatSymbols;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Scanner;

public class RequestProcessor extends Thread {
	
	private Socket s;
	
	public RequestProcessor(Socket s){
		this.s = s;
	}
	
	public void run() {
		try {
			InputStream is = s.getInputStream();
			OutputStream os = s.getOutputStream();
			int check = 0;
			
			while(true) {
				double sotien = 0;
				
				byte[] b = new byte[1000];
				check = is.read(b);
				String cmd = new String(b).trim();
				String cardNumber = "";
				String pin = "";
				String request = "";
				String amount = "";
				
				if(cmd.contains("CARDNUMBER")){
					cardNumber = cmd.substring(cmd.indexOf("CARDNUMBER")+10, cmd.indexOf("ENDCARDNUMBER"));
				}
				if(cmd.contains("PIN")){
					pin = cmd.substring(cmd.indexOf("PIN")+3, cmd.indexOf("ENDPIN"));
				}
				if(cmd.contains("REQUEST")){
					request = cmd.substring(cmd.indexOf("REQUEST")+7, cmd.indexOf("ENDREQUEST"));
				}
				if(cmd.contains("AMOUNT")){
					amount = cmd.substring(cmd.indexOf("AMOUNT")+6, cmd.indexOf("ENDAMOUNT"));
					sotien = Double.parseDouble(amount);
				}
				System.out.println("Card number: "+cardNumber+", Request: "+request);
		        				
		        if(cmd.contains("LOGIN")) {
		        	String response = "invalid";
		        	if(isLoginValid(cardNumber, pin)) {
		        		response = "valid";
		        	}
		        	os.write(response.getBytes());
		        } else if(cmd.contains("WITHDRAW")) {
					String money = withdraw(cardNumber, sotien);
					os.write(money.getBytes());
					
				} else if(cmd.contains("CHECK")) {
					String report = "Balance: " + Double.parseDouble(getAccountBalance(cardNumber));
					os.write(report.getBytes());
				}
			}
		} catch (IOException e) {}
	}
	
	private synchronized String withdraw(String cardNumber, double sotien) {
		int _500 = 0;
		int _200 = 0;
		int _100 = 0;
		int _50 = 0;
		String notify = "";
		double balance = Double.parseDouble(getAccountBalance(cardNumber));
		double withdrawAmount = sotien;
		if( balance >= sotien) {
			if(sotien == 0) {
				System.out.println("Failed!");
				notify = "So tien da nhap khong hop le!";
				return notify;
			}
			while(sotien > 0) {
				if(sotien >= 500000) {
					sotien -= 500000;
					_500++;
				} else if(sotien < 500000 && sotien >= 200000) {
					sotien -= 200000;
					_200++;
				} else if(sotien < 200000 && sotien >= 100000) {
					sotien -= 100000;
					_100++;
				} else if(sotien == 50000) {
					sotien -= 50000;
					_50++;
				} else {
					System.out.println("Not valid!");
					notify = "So tien da nhap khong hop le!";
					return notify;
				}
			}
			
			updateAccountBalance(cardNumber, withdrawAmount);
			notify ="Tien rut: "+withdrawAmount+
					"\nCon lai: "+getAccountBalance(cardNumber)+
					"\nSo to 500: "+_500+
					"\nSo to 200: "+_200+
					"\nSo to 100: "+_100+
					"\nSo to  50: "+_50 + 
					"\nTong so to: "+(_500+_200+_100+_50);
		} else {
			System.out.println("Not enough!");
			notify = "So tien trong tai khoan khong du!";
		}
		return notify;
	}
	
	private synchronized boolean isLoginValid(String cardNumber, String inputPIN) {
		ClassLoader classloader = Thread.currentThread().getContextClassLoader();
		InputStream fileAccount = classloader.getResourceAsStream(cardNumber + ".txt");
		if (fileAccount != null) {			
			Scanner sc = new Scanner(fileAccount);
			if (sc.hasNextLine()) {
				String cardInfo = sc.nextLine().trim();
				String sysPIN = cardInfo.substring(cardInfo.indexOf("PIN") + 3 , cardInfo.indexOf(" "));
				sc.close();
				return sysPIN.equals(inputPIN);
			} else {
				sc.close();			
				return false;
			}
		} else {
			return false;
		}
	}
	
	private synchronized String getAccountBalance(String cardNumber) {
		ClassLoader classloader = Thread.currentThread().getContextClassLoader();
		InputStream fileAccount = classloader.getResourceAsStream(cardNumber + ".txt");
		
		Scanner sc = new Scanner(fileAccount);
		if (sc.hasNextLine()) {
			String cardInfo = sc.nextLine().trim();
			sc.close();
			return cardInfo.substring(cardInfo.indexOf("BALANCE")+7);				
		} else {
			sc.close();			
			return "Fail";
		}
		
	}
	
	private synchronized void updateAccountBalance(String cardNumber, Double amount) {
		ClassLoader classloader = Thread.currentThread().getContextClassLoader();
		InputStream fileAccount = classloader.getResourceAsStream(cardNumber + ".txt");
		
		Scanner sc = new Scanner(fileAccount);
		String oldBalance = "";
		String newBalance = "";
		
		if (sc.hasNextLine()) {
			String cardInfo = sc.nextLine();
			oldBalance = cardInfo.substring(cardInfo.indexOf("BALANCE")+7);
			newBalance = (Double.parseDouble(oldBalance) - amount)+"";
		}
		
		String p = classloader.getResource(cardNumber + ".txt").getPath().substring(1);
		Path path = Paths.get(p);
		
		String content;
		try {
			content = new String(Files.readAllBytes(path), StandardCharsets.UTF_8);
			String oldString = "CARDNUMBER"+cardNumber+" BALANCE"+oldBalance;
			String newString = "CARDNUMBER"+cardNumber+" BALANCE"+newBalance;
			content = content.replace(oldString, newString);								
			Files.write(path, content.getBytes(StandardCharsets.UTF_8));
		} catch (IOException e) {
			e.printStackTrace();
		}
		sc.close();
	}
}
