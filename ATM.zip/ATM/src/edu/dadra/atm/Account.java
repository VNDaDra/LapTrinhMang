package edu.dadra.atm;

public class Account {

	private String cardNumber;
	private String pinCode;
	private double balance;
	
	public Account(String cardNumber, String pinCode, double balance) {
		super();
		this.cardNumber = cardNumber;
		this.pinCode = pinCode;
		this.balance = balance;
	}

	public String getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}

	public String getPinCode() {
		return pinCode;
	}

	public void setPinCode(String pinCode) {
		this.pinCode = pinCode;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	
	
}
