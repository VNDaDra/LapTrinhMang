package PT;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {
	
	private final static int port = 77;
	
	public static void main(String[] args) throws IOException{
		
		ServerSocket serverSocket = new ServerSocket(port);
		System.out.println("Server is starting...");
		
		while(true) {
			Socket socket = serverSocket.accept();
			
			InputStream inputStream = socket.getInputStream();
			byte data[] = new byte[2048];
			inputStream.read(data);
			String input = new String(data).trim();
			System.out.println(input);
			
			String cmd[];
			cmd = input.split(" ");
			
			if(input.contains("Giaiptb1")) {
				PhuongTrinhBac1 pt1 = new PhuongTrinhBac1(socket, 
						Integer.parseInt(cmd[1]), 
						Integer.parseInt(cmd[2]));
				pt1.start();
			} else if (input.contains("Giaiptb2")){
				PhuongTrinhBac2 pt2 = new PhuongTrinhBac2(socket, 
						Integer.parseInt(cmd[1]), 
						Integer.parseInt(cmd[2]), 
						Integer.parseInt(cmd[3]));
				pt2.start();
			}
		}

	}

}
