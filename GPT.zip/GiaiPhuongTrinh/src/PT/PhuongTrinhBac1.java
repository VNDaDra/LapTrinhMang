package PT;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class PhuongTrinhBac1 extends Thread{
	
	private Socket socket;
	private int a,b;
	
	public PhuongTrinhBac1(Socket socket, int a, int b) {
		this.socket = socket;
		this.a = a;
		this.b = b;
	}
	
	public void run(){
		try {
			InputStream inputStream = socket.getInputStream();
			OutputStream outputStream = socket.getOutputStream();
			
			System.out.println(a + " - " + b);
			float nghiem;
			String result;
			if (a == 0) {
	            if (b == 0) {
	            	result = "Phuong trinh co vo so nghiem";
	                System.out.println(result);
	            } else {
	            	result = "Phuong trinh vo nghiem";
	                System.out.println(result);
	            }
	        } else {
	            nghiem = (float) -b / a;
	            result = "Nghiem cua phuong trinh: " + String.valueOf(nghiem);
	            System.out.println(result);
	        }
			
			outputStream.write(result.getBytes());
						
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
