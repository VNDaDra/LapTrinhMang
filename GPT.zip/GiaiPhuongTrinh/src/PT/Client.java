package PT;

import java.io.IOException;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class Client {

	public static void main(String[] args) {

		String loaiPT = args[0];
		String a = args[1];
		String b = args[2];
		String c = "";
		
		if(loaiPT.equals("Giaiptb2")) {
			c = args[3];
		}
		int port = 77;
		
		String pt = loaiPT+" "+a+" "+b+" "+c;
		
		Socket s = null;
		try {

			s = new Socket("localhost", port);
			InputStream is = s.getInputStream();
			OutputStream os = s.getOutputStream();

			os.write(pt.getBytes());

			byte[] dataByte = new byte[2048];
			is.read(dataByte);
			String result = new String(dataByte).trim();
			System.out.println("result: " + result);

		} catch (IOException e) {
			e.printStackTrace();
		}

	}

 

}
