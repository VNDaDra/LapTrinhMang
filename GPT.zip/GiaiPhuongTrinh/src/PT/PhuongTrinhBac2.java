package PT;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class PhuongTrinhBac2 extends Thread{

	private Socket socket;
	private int a,b,c;
	
	public PhuongTrinhBac2(Socket socket, int a, int b, int c) {
		this.socket = socket;
		this.a = a;
		this.b = b;
		this.c = c;
	}
	
	public void run(){
		try {
			InputStream inputStream = socket.getInputStream();
			OutputStream outputStream = socket.getOutputStream();
			
			System.out.println(a + " - " + b + " - " + c);
			float nghiem;
			String result;
			
			if (a == 0) {
	            if (b == 0) {
	            	result = "Phuong trinh vo nghiem do a b bang 0";
	                System.out.println(result);
	            } else {
	            	nghiem = -c / b;
	            	result = "Phuong trinh co 1 nghiem: " + nghiem;
	                System.out.println(result);
	            }
	            
	        } else {
				float delta = b*b - 4*a*c;
		        float x1;
		        float x2;

		        if (delta > 0) {
		            x1 = (float) ((-b + Math.sqrt(delta)) / (2*a));
		            x2 = (float) ((-b - Math.sqrt(delta)) / (2*a));
		            result = "Co 2 nghiem la: " + x1 + " va " + x2;
		            System.out.println(result);
		            
		        } else if (delta == 0) {
		            x1 = (-b / (2 * a));
		            result = "Phuong trinh co nghiem kep: " + x1;
		            System.out.println(result);
		        } else {
		        	result = "Phuong trinh vo nghiem do delta < 0";
		            System.out.println(result);
		        }
				
			}
			
			outputStream.write(result.getBytes());
			
	       		
		} catch (IOException e) {
			e.printStackTrace();
		}
		

	}

}
