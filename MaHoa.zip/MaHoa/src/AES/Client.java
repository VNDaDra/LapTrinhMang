package AES;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Client {

	private final static int port = 77;
	
	public static void main(String[] args) throws Exception{
		Socket s = new Socket("localhost", port);
		InputStream is = s.getInputStream();
		OutputStream os = s.getOutputStream();
		
		Scanner sc = new Scanner(System.in);
		while (true) {
			byte b[] = new byte[2048];
			System.out.print("Input string to encrypt: ");
			String needEncrypt = sc.nextLine();
			
			if(needEncrypt.isEmpty()) s.close();;
			
			os.write(needEncrypt.getBytes());
				
			is.read(b);
			String result = new String(b).trim();
			System.out.println(result);
		}


	}

}
