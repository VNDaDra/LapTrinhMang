package AES;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Server {
	
	private final static int port = 77;
	private final static String key = "1234567890123456";
	
	public static void main(String[] args) throws Exception{
		ServerSocket ss = new ServerSocket(port);
		while (true) {
			Socket s = ss.accept();
			OutputStream os = s.getOutputStream();
			InputStream is = s.getInputStream();
			
			while (true) {
				byte b[] = new byte[2048];
				
				is.read(b);
				String input = new String(b).trim();
				System.out.println("Receive: " + input);
				
				if (input.contains("MaHoa")) {
					String needEncryptString = input.substring(input.indexOf("MaHoa") + 6);
					String encryptString = encrypt(needEncryptString, key);
					os.write(encryptString.getBytes());
					System.out.println("Return: " + encryptString);
				} else if(input.contains("GiaiMa")) {
					String needDecryptString = input.substring(input.indexOf("GiaiMa") + 7);
					String decryptString = decrypt(needDecryptString, key);
					os.write(decryptString.getBytes());
					System.out.println("Return: " + decryptString);
				} else {
					os.write("Bad request".getBytes());
					System.out.println("Bad request");
				}
				
				
				
			}
		}
	}
	
	public static String encrypt(String strToEncrypt, String myKey) {
	      try {
	            MessageDigest sha = MessageDigest.getInstance("SHA-1");
	            byte[] key = myKey.getBytes("UTF-8");
	            key = sha.digest(key);
	            key = Arrays.copyOf(key, 16);
	            SecretKeySpec secretKey = new SecretKeySpec(key, "AES");
	            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");
	            cipher.init(Cipher.ENCRYPT_MODE, secretKey);
	            return Base64.getEncoder().encodeToString(cipher.doFinal(strToEncrypt.getBytes("UTF-8")));
	      } catch (Exception e) {
	            System.out.println(e.toString());
	      }
	      return null;
	}
	
	public static String decrypt(String strToDecrypt, String myKey) {
	      try {
	            MessageDigest sha = MessageDigest.getInstance("SHA-1");
	            byte[] key = myKey.getBytes("UTF-8");
	            key = sha.digest(key);
	            key = Arrays.copyOf(key, 16);
	            SecretKeySpec secretKey = new SecretKeySpec(key, "AES");
	            Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
	            cipher.init(Cipher.DECRYPT_MODE, secretKey);
	            return new String(cipher.doFinal(Base64.getDecoder().decode(strToDecrypt)));
	      } catch (Exception e) {
	            System.out.println(e.toString());
	      }
	      return null;
	}

}
