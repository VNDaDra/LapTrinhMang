package Bai3;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class FileClient {
	
	public static void main(String[] args) throws Exception{
		while (true) {
			MulticastSocket socket = new MulticastSocket(9013);
			InetAddress address = InetAddress.getByName("224.0.0.0");
			socket.joinGroup(address);
			
			byte message[] = new byte[2048];
			DatagramPacket packet = new DatagramPacket(message, message.length);		
			
			socket.receive(packet);
			
			String fileContent = new String(packet.getData());
			System.out.println("Receive: \n" + fileContent.trim());
			
//			socket.leaveGroup(address);
//			socket.close();
		}
		
		
	}
	
}
