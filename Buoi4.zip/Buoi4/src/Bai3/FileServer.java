package Bai3;

import java.io.File;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.file.Files;

public class FileServer {
	
	public static void main(String[] args) throws Exception{
		DatagramSocket socket = new DatagramSocket(1213);
		while (true) {
			ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
			File file = new File(classLoader.getResource("test.txt").getFile());
			byte content[] = Files.readAllBytes(file.toPath());
			String fileContent = new String(content);
			
			byte buffer[] = fileContent.getBytes();			
			
			InetAddress address = InetAddress.getByName("224.0.0.0");
			
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length, address, 9013);
			socket.send(packet);
			System.out.println("Send: \n" + fileContent);
			Thread.sleep(5000);
		}

	}
}
