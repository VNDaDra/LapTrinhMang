package TH;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.Date;

public class MulticastTimeServer {

	public static void main(String[] args) throws Exception{
		DatagramSocket socket = new DatagramSocket(1213);
		while (true) {
			String date = new Date().toString();
			byte buffer[] = date.getBytes();
			
			InetAddress address = InetAddress.getByName("224.0.0.0");
			
			DatagramPacket packet = new DatagramPacket(buffer, buffer.length, address, 9013);
			socket.send(packet);
			System.out.println("Send " + date);
			Thread.sleep(5000);
		}

	}

}
